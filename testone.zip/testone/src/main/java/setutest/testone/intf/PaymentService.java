package setutest.testone.intf;

import setutest.testone.DAO.PaymentRequest;
import setutest.testone.DAO.*;
import setutest.testone.util.CommonResponse;
public interface PaymentService {
	public CommonResponse<PaymentResponse> makePayment(PaymentRequest pmtrq);
	
}
