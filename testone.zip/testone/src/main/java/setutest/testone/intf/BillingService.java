package setutest.testone.intf;

import setutest.testone.DAO.BillingResponse;
import setutest.testone.DAO.*;
import setutest.testone.util.CommonResponse;

public interface BillingService {
	public CommonResponse<BillingResponse> billing(long mobile_num);
	//public BillingResponse billing(int mobile_num);
	
}
