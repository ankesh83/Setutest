package setutest.testone.resources;

import javax.jws.WebService;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.xml.bind.annotation.XmlRootElement;

import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.ApiResponse;
import setutest.testone.DAO.*;
import setutest.testone.impl.BillingServiceImpl;
import setutest.testone.impl.PaymentServiceImpl;
import setutest.testone.intf.BillingService;
import setutest.testone.intf.PaymentService;
import setutest.testone.util.ApiKeysAttribute;
import setutest.testone.util.CommonResponse;
import setutest.testone.util.Constants;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@Path("api")
public class BillingResource {
	/*@Context
    ContainerRequestContext crc;
	/**
     * Returns Bill Data
     * @param mobile_num
     * @return Response
     */
	@POST
    @Path("v1/fetch-bill")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
    public Response getAccountDetail(Input inp) {
		BillingService billservice = new BillingServiceImpl();
		long mobile_num = inp.getmobileNumber();
		ContainerRequestContext requestContext = null;
		BillingResponse billresp = new BillingResponse();
		/*ApiKeysAttribute api = new ApiKeysAttribute();
		try {
			api.filter(requestContext);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			billresp.setErrorCode("auth-error");
			billresp.setStatus("ERROR");
			CommonResponse<BillingResponse> pmtresponse = new CommonResponse<BillingResponse>(billresp, Constants.SERVICE_403_RESP);
			return  Response.status(pmtresponse.getResponseCode()).entity(pmtresponse.getResponseObject()).build();

		}*/
	CommonResponse<BillingResponse> billresponse = billservice.billing(mobile_num);
	return  Response.status(billresponse.getResponseCode()).entity(billresponse.getResponseObject()).build();
	}
	
	@POST
    @Path("v1/payment-update")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
    public Response postpayment(PaymentRequest pmt_ip) {
		PaymentService pmtservice = new PaymentServiceImpl();
		
		ContainerRequestContext requestContext = null;
		PaymentResponse pmtresp = new PaymentResponse();
		/*ApiKeysAttribute api = new ApiKeysAttribute();
	try {
		api.filter(requestContext);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		pmtresp.setErrorCode("auth-error");
		pmtresp.setStatus("ERROR");
		CommonResponse<PaymentResponse> pmtresponse = new CommonResponse<PaymentResponse>(pmtresp, Constants.SERVICE_403_RESP);
		return  Response.status(pmtresponse.getResponseCode()).entity(pmtresponse.getResponseObject()).build();

	}	*/
	CommonResponse<PaymentResponse> pmtresponse = pmtservice.makePayment(pmt_ip);
	return  Response.status(pmtresponse.getResponseCode()).entity(pmtresponse.getResponseObject()).build();
	}
}
