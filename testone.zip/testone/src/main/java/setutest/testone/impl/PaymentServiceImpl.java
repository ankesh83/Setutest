package setutest.testone.impl;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.core.Response;

import setutest.testone.DAO.BillingData;
import setutest.testone.DAO.BillingResponse;
import setutest.testone.DAO.Data;
import setutest.testone.DAO.PaymentRequest;
import setutest.testone.DAO.PaymentResponse;
import setutest.testone.intf.PaymentService;
import setutest.testone.util.CommonResponse;
import setutest.testone.util.Constants;
import setutest.testone.util.DBConnection;

public class PaymentServiceImpl implements PaymentService{

	@Override
	public CommonResponse<PaymentResponse> makePayment(PaymentRequest pmtrq) {
		// TODO Auto-generated method stub
		System.out.println("inside impl method");
		PaymentResponse pmtresp = new PaymentResponse();
		ContainerRequestContext requestContext = null;
		Data data = new Data();
		String ack_id_final = null;
		
		String Ack_id  = "PMT"+(((int) (Math.random()*(100000000 - 1))) + 1);
		CommonResponse<PaymentResponse> cmnresp = null;
		try {
			//Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection	con  = DBConnection.getInstance().getConnection();//DriverManager.getConnection("jdbc:oracle:thin:whf00mgm:1521:ofsll143", "OFSLL1431R71", "ofsll1431r71");

				PreparedStatement stm = con.prepareStatement(Constants.PAYMENT_SQL_QUERY);
				PreparedStatement bill_stm = con.prepareStatement(Constants.BILLING_CHECK_SQL_QUERY);
				System.out.println(pmtrq.getTxns().getAmt_paid());
				System.out.println(pmtrq.getTxns().getPayment_date());
				System.out.println(pmtrq.getRef_id());
				System.out.println(Ack_id);
				stm.setInt(1, pmtrq.getTxns().getAmt_paid());
				stm.setString(2,  pmtrq.getTxns().getPayment_date());
				stm.setString(3, pmtrq.getTxns().getPayment_id());
				stm.setString(4, Ack_id);
				stm.setString(5, pmtrq.getRef_id());
				bill_stm.setString(1, pmtrq.getRef_id());
				stm.executeUpdate();
				System.out.println("after execute");
				ResultSet rs = bill_stm.executeQuery();
				System.out.println("after query");
				if(rs.next()) {
					if(rs.getInt(3) != pmtrq.getTxns().getAmt_paid()) {
						pmtresp.setStatus("ERROR");
						pmtresp.setErrorCode("amount-mismatch");
						cmnresp = new CommonResponse<PaymentResponse>(pmtresp, Constants.SERVICE_400_RESP);
						return cmnresp;
					}
					ack_id_final = rs.getNString("ACK_ID");
				}else {
					pmtresp.setStatus("ERROR");
					pmtresp.setErrorCode("invalid-ref-id");
					cmnresp = new CommonResponse<PaymentResponse>(pmtresp, Constants.SERVICE_400_RESP);
					return cmnresp;
				}
					
				pmtresp.setStatus("SUCCESS");
				data.setAck_id(ack_id_final);
				pmtresp.setdata(data);
				

			} catch (SQLException e) {
				pmtresp.setStatus("ERROR");
				pmtresp.setErrorCode("unhandled-error");
				cmnresp = new CommonResponse<PaymentResponse>(pmtresp, Constants.SERVICE_500_RESP);
				return cmnresp;

		}
		
			cmnresp = new CommonResponse<PaymentResponse>(pmtresp, Constants.RESPONSE_STATUS_OK);
				
		return cmnresp;
	}
	}

