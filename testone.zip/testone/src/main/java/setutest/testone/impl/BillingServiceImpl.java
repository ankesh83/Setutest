package setutest.testone.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.core.Response;

import setutest.testone.DAO.BillingData;
import setutest.testone.DAO.BillingResponse;
import setutest.testone.DAO.ErrorResponse;
import setutest.testone.intf.BillingService;
import setutest.testone.util.CommonResponse;
import setutest.testone.util.Constants;
import setutest.testone.util.DBConnection;

public class BillingServiceImpl implements BillingService{

	@Override
	/**
     *  retruns  Account Details data from the package call
     * @param mobile_num
     * @return CommonResponse
     */
	public CommonResponse<BillingResponse> billing(long mobile_num) {
	//public BillingResponse billing(int mobile_num) {
	
		System.out.println("inside impl method");
		BillingResponse billingresp = new BillingResponse();
		BillingData data = new BillingData();
		ContainerRequestContext requestContext = null;
		//ErrorResponse errresp = new ErrorResponse();
		boolean ispresent = false;
		//Response.Status responseCode=Constants.RESPONSE_STATUS_OK; 
		CommonResponse<BillingResponse> cmnresp = null;
		try {
			//Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection	con  = DBConnection.getInstance().getConnection();//DriverManager.getConnection("jdbc:oracle:thin:whf00mgm:1521:ofsll143", "OFSLL1431R71", "ofsll1431r71");
			PreparedStatement stm = con.prepareStatement(Constants.BILLING_SQL_QUERY + mobile_num);
			ResultSet rs = stm.executeQuery();
			while(rs.next()) {
				ispresent = true;
				billingresp.setStatus("SUCCESS");
				data.setCustomerName(rs.getNString(2));
				//billdata.setCustomername(rs.getString("CUST_NAME"));
				//billdata.setCustomername("Ankesh");
				//billdata.setDueamt(2000);
				
				data.setDueAmt(rs.getInt(3));
				data.setDueDate(rs.getDate(4));
				data.setRefId(rs.getNString(5));
				billingresp.setdata(data);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			Response internalservererror = Response.status(Constants.SERVICE_500_RESP).entity("unhandled-error").build();
			requestContext.abortWith(internalservererror);

		}
		if(ispresent){
			cmnresp = new CommonResponse<BillingResponse>(billingresp, Constants.RESPONSE_STATUS_OK);
		}else {
			billingresp.setStatus("ERROR");
			billingresp.setErrorCode("customer-not-found");
			cmnresp = new CommonResponse<BillingResponse>(billingresp, Constants.SERVICE_400_RESP);

		}
			
		return cmnresp;
	}
	
}
