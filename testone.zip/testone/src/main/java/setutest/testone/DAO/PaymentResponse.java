package setutest.testone.DAO;

public class PaymentResponse {
	private String status;
	private Data data;
	private String errorCode;
	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Data getdata() {
		return data;
	}

	public void setdata(Data data) {
		this.data = data;
	}
}
