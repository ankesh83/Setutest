package setutest.testone.DAO;

public class Input {
private long mobileNumber;

public void setmobileNumber(long mobileNumber) {
	this.mobileNumber = mobileNumber;
}

public long getmobileNumber() {
	return mobileNumber;
}

}
