package setutest.testone.DAO;

public class TransactionResponse {
	private String status;
	private Data ack;
}
