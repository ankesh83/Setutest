package setutest.testone.DAO;

import java.util.Date;

public class BillingData {
	private String customerName;
	private int dueAmt;
	private Date dueDate;
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public int getDueAmt() {
		return dueAmt;
	}
	public void setDueAmt(int dueamt) {
		this.dueAmt = dueamt;
	}
	public Date getDueDate() {
		return dueDate;
	}
	public void setDueDate(Date duedate) {
		this.dueDate = duedate;
	}
	public String getRefId() {
		return refId;
	}
	public void setRefId(String refid) {
		this.refId = refid;
	}
	private String refId;
}
