package setutest.testone.DAO;

public class PaymentRequest {
	private String ref_id;
	private Transaction txns;
	public String getRef_id() {
		return ref_id;
	}
	public void setRef_id(String ref_id) {
		this.ref_id = ref_id;
	}
	public Transaction getTxns() {
		return txns;
	}
	public void setTxns(Transaction txns) {
		this.txns = txns;
	}
	
}
