package setutest.testone.DAO;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
@JsonSerialize()
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BillingResponse {
	private String status;
	private BillingData data;
	private String errorCode;
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status; 
	}
	public BillingData getdata() {
		return data;
	}
	public void setdata(BillingData data) {
		this.data = data;
	}
	
	
}
