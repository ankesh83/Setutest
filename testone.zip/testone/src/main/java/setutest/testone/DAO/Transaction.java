package setutest.testone.DAO;

import java.util.Date;

public class Transaction {
	private int amt_paid;
	private String payment_date;
	private String Payment_id;
	public void setAmt_paid(int amt_paid) {
		this.amt_paid = amt_paid;
	}
	public int getAmt_paid() {
		return amt_paid;
	}
	public String getPayment_date() {
		return payment_date;
	}
	public String getPayment_id() {
		return Payment_id;
	}
	public void setPayment_date(String payment_date) {
		this.payment_date = payment_date;
	}
	public void setPayment_id(String payment_id) {
		Payment_id = payment_id;
	}
	
}
