package setutest.testone.DAO;

public class Data {
	private String ackID;

	public String getAck_id() {
		return ackID;
	}

	public void setAck_id(String ackID) {
		this.ackID = ackID;
	}
	
}
