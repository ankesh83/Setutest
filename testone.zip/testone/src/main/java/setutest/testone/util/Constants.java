package setutest.testone.util;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.StatusType;

public final class Constants {
	private Constants() {
		
	}
	public static final Response.Status RESPONSE_STATUS_OK=Response.Status.OK;
	public static final String DATA_SOURCE = "";
	public static final String BILLING_SQL_QUERY = "Select * from BILLING where MOBILE_NUMBER  =";
	public static final String BILLING_CHECK_SQL_QUERY = "Select * from BILLING where REF_ID  =?";
	public static final String PAYMENT_SQL_QUERY = "UPDATE BILLING SET AMOUNT_PAID = ?, PAYMENT_DATE = ?,   PMT_ID =?,  ACK_ID =?  WHERE AMOUNT_PAID IS NULL AND REF_ID =?";
	public static final String JSON_ROOT_NODE_START_DESC = "\n<br> <b>Note :</b> Start below JSON example with node \n {\n  \"";
    public static final String JSON_ROOT_NODE_END_DESC = "\":\n <br>  and end  with \n } ";
    public static final Response.Status SERVICE_400_RESP = Response.Status.BAD_REQUEST;
    public static final String INVALID_AUTH_TOKEN=" Invalid Auth Token";
    public static final Response.Status SERVICE_401_RESP = Response.Status.UNAUTHORIZED;
    public static final Response.Status SERVICE_500_RESP = Response.Status.INTERNAL_SERVER_ERROR;
    public static final Response.Status SERVICE_403_RESP = Response.Status.FORBIDDEN;
    public static final String SERVICE_404_RESP = "invalid-ref-id";
    public static final String user_key			= "ankesh";
}
