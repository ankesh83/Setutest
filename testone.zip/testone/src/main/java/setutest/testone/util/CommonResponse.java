package setutest.testone.util;
import javax.ws.rs.core.Response;

import com.fasterxml.jackson.annotation.JsonInclude;
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CommonResponse<T> {
    private T responseObject;
    private Response.Status responseCode;
    private String customField;


    public CommonResponse(T responseObject, Response.Status responseCode) {
        this.responseObject = responseObject;
        this.responseCode = responseCode;
    }
    
    public CommonResponse(T responseObject, Response.Status responseCode, String customField) {
        this.responseObject = responseObject;
        this.responseCode = responseCode;
        this.customField = customField;
    }

    public T getResponseObject() {
        return responseObject;
    }

    public Response.Status getResponseCode() {
        return responseCode;
    }
    
    public String getCustomField() {
        return customField;    
    }

    public void setResponseCode(Response.Status responseCode) {
        this.responseCode = responseCode;
    }
}
