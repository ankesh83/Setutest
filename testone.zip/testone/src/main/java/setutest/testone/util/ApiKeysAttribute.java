package setutest.testone.util;

import java.io.IOException;
import java.util.List;
import java.util.StringTokenizer;

import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.Provider;

import com.sun.jersey.core.util.Base64;
@Provider
public class ApiKeysAttribute implements ContainerRequestFilter {
	private static final String AUTH_HEADER_KEY = "X-API-KEY";
	//private static final String AUTH_HEADER_PREFIX = "Basic ";
	@Override
	public void filter(ContainerRequestContext requestContext) throws IOException {
		// TODO Auto-generated method stub
		String apikey=null;
        //String credential=null;
        String accessTokenValue  = null;
		List<String> authheader = requestContext.getHeaders().get(AUTH_HEADER_KEY);
		if(authheader.size() > 0) {
			String authtoken = authheader.get(0);
			//authtoken = authtoken.replaceFirst(AUTH_HEADER_PREFIX, "");
			//byte[] decoded = Base64.decode(authtoken);
			//String  decodestring  = new String(decoded);
			//StringTokenizer userNameCredential = new StringTokenizer(decodestring, ":");
			/*if (userNameCredential.hasMoreTokens()) {
                userName = userNameCredential.nextToken();
                credential = userNameCredential.nextToken();
                if("user".equals(userName) && "password".equals(credential)) {
                	return;
                }
            }*/
			if(Constants.user_key.equals(authtoken)) {
				return;
			}
			Response unauthorizedstatus = Response.status(Constants.SERVICE_401_RESP).entity("auth-error").build();
			requestContext.abortWith(unauthorizedstatus);
		}
	}

}
